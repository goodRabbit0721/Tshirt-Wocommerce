<script src="<?php echo site_url('assets/plugins/perfect-scrollbar/src/jquery.mousewheel.js'); ?>"></script>
<script src="<?php echo site_url('assets/plugins/perfect-scrollbar/src/perfect-scrollbar.js'); ?>"></script>
<script src="<?php echo site_url('assets/plugins/blockUI/jquery.blockUI.js'); ?>"></script>
<script src="<?php echo site_url('assets/js/main.js'); ?>"></script>
<script src="<?php echo site_url('assets/plugins/validate/validate.js'); ?>"></script>
<script>
	jQuery(document).ready(function() {
		Main.init();				
	});
</script>
<!-- start: FOOTER -->
		<div class="footer clearfix">
			<div class="footer-inner">
				&copy; <a href="http://tshirtecommerce.com/" target="_blank">tshirtecommerce.com</a>
			</div>
			<div class="footer-items">
				<span class="go-top"><i class="clip-chevron-up"></i></span>
			</div>
		</div>			
	</body>
	<!-- end: BODY -->
</html>