<?php 
/**
 * WordPress Native Editor
 * Page Composer Section
 *
 * @package SimpleMag
 * @since 	SimpleMag 3.0
**/
?>

<section class="wrapper home-section entry-content clearfix">
	<?php the_sub_field( 'wp_ti_editor' ); ?>
</section><!-- WP Editor -->